
// typical import
import gsap from "gsap";

// get other plugins:
import ScrollTrigger from "gsap/ScrollTrigger";

// don't forget to register plugins
gsap.registerPlugin(ScrollTrigger); 



import Lenis from '@studio-freight/lenis'

const lenis = new Lenis()

lenis.on('scroll', (e) => {
  console.log(e)
})

function raf(time) {
  lenis.raf(time)
  requestAnimationFrame(raf)
}

requestAnimationFrame(raf)


/*
  const navigationMobileBackground = document.querySelector('.navigation-mobile-background');
  const navigationMobileButton = document.querySelector('.navigation-mobile');

  // Create a new GSAP timeline
  // Create a new GSAP timeline
const mobileNavAnimation = gsap.timeline({
  paused: true
});

// Add the animations to the timeline
mobileNavAnimation
  .to('.navigation-mobile-background', {
    duration: 0.3,
    ease: 'power2.out',
    opacity: 1,
    pointerEvents: 'all'
  })
  .to('.navigation-mobile-background', {
    duration: 0.3,
    ease: 'power2.out',
    y: '30px'
  })
  .to('.navigation-mobile-background', {
    duration: 0.3,
    ease: 'power2.out',
    y: '0',
    pointerEvents: '0',
    opacity: 0
  });

// Add a click event listener to the navigation mobile button
navigationMobileButton.addEventListener('click', function() {
  mobileNavAnimation.play(); // Play the animation
});
*/

/*
 
  const playButton = document.querySelector('.whatdoioffer-1 .icon .play-button');
const pauseButton = document.querySelector('.whatdoioffer-1 .icon .pause-button');
const video = document.querySelector('.whatdoioffer-video');
const videoContainer = document.querySelector('.whatdoioffer-1');

playButton.addEventListener('click', () => {
  video.play();
  playButton.style.opacity = '0';
  pauseButton.style.opacity = '1';
  pauseButton.style.zIndex = '0';
  playButton.style.zIndex = '1';
});

pauseButton.addEventListener('click', () => {
  video.pause();
  pauseButton.style.opacity = '0';
  playButton.style.opacity = '1';
  pauseButton.style.zIndex = '0';
  playButton.style.zIndex = '1';
});

video.addEventListener('play', () => {
  playButton.style.opacity = '0';
  pauseButton.style.opacity = '1';
  playButton.style.zIndex = '0';
  pauseButton.style.zIndex = '1';
});

video.addEventListener('pause', () => {
  pauseButton.style.opacity = '0';
  playButton.style.opacity = '1';
  pauseButton.style.zIndex = '0';
  playButton.style.zIndex = '1';
});

videoContainer.addEventListener('mouseenter', () => {
  if (video.paused) {
    pauseButton.style.opacity = '0';
    playButton.style.opacity = '1';
    pauseButton.style.zIndex = '0';
    playButton.style.zIndex = '1';
  } else {
    playButton.style.opacity = '0';
    pauseButton.style.opacity = '1';
    playButton.style.zIndex = '0';
    pauseButton.style.zIndex = '1';
  }
});

videoContainer.addEventListener('mouseleave', () => {
  pauseButton.style.opacity = '0';
});

const switchItems = document.querySelectorAll('.whatdoioffer-swtich-item');
const indicators = document.querySelectorAll('.whatdoioffer-1, .whatdoioffer-2, .whatdoioffer-3, .whatdoioffer-4');

// Set the initial 'data-active' state
switchItems.forEach((item, index) => {
  if (index === 0) {
    item.setAttribute('data-active', 'true');
  } else {
    item.setAttribute('data-active', 'false');
  }
});

// Add click event listener to the switch items
switchItems.forEach((item, index) => {
  item.addEventListener('click', () => {
    // Remove 'data-active="true"' from all switch items
    switchItems.forEach(i => i.setAttribute('data-active', 'false'));
    // Set 'data-active="true"' to the clicked switch item
    item.setAttribute('data-active', 'true');

    // Hide all indicators
    indicators.forEach(i => i.setAttribute('data-active', 'false'));
    // Show the corresponding indicator
    indicators[index].setAttribute('data-active', 'true');
  });
});
 */ 
