


module.exports = {
    plugins: [
        require('postcss-reporter'),
        require('autoprefixer'),
        require('cssnano'),
    ],
};


